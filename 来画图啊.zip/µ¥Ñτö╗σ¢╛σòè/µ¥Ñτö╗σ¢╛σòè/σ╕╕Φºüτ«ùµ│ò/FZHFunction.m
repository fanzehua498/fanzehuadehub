//
//  FZHFunction.m
//  来画图啊
//
//  Created by ydcy-mini on 2017/4/14.
//  Copyright © 2017年 ydcy-mini. All rights reserved.
//

#import "FZHFunction.h"

@implementation FZHFunction

- (int)halfFunctionIntArr:(NSArray *)a number:(int) number
{
    if (a.count == 0) {
        return -1;
    }
    int start = 0;
    int index = 0;
    int end = (int)a.count - 1;
    while (start + 1 < end) {
        index = start + (end - start)/2;
        if ([a[index] intValue] == number) {
            return index;
        }else if ([a[index] intValue] < number){
            start = index ;
        }else{
            end = index ;
        }

    }
    if ([a[start] intValue] == number) {
        return start;
    }
    if ([a[end] intValue] == number) {
        return end;
    }

    return index;
}

-(NSMutableArray *)maopaoSort:(NSMutableArray *)arr orderOrDisorder:(BOOL)order
{
    for (int i = 0; i < arr.count - 1; i++) {
        for (int j =0; j <arr.count - 1 - i; j ++) {
            if (order) {
                if (arr[j] > arr[j+1]) {
                    id temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                }

            } else {
                if (arr[j] < arr[j+1]) {
                    id temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                }

            }

        }
    }

    return arr;
}

-(NSMutableArray *)chooseSort:(NSMutableArray *)arr orderOrDisorder:(BOOL)order
{
    for (int i = 0; i < arr.count-1; i++) {
        for (int j = i+1; j<arr.count; j++) {
            if (order) {
                if(arr[i]>arr[j]){
                    id temp = arr[j];
                    arr[j] = arr[i];
                    arr[i] = temp;
                }

            }else{
                if(arr[i]<arr[j]){
                    id temp = arr[j];
                    arr[j] = arr[i];
                    arr[i] = temp;
                }

            }
        }
    }

    return arr;
}

//int halfFuntion(int a[], int length, int number)
//{
//    int start = 0;
//    int end = length - 1;
//    int index = 0;
//    while(start < end)
//    {
//        index = start + (end - start)/2;
//        if(a[index] == number){
//            return index;
//        } else if(a[index] < number){
//            start = index + 1;
//        } else{
//            end = index - 1;
//        }
//    }
//    return index;
//}

@end
