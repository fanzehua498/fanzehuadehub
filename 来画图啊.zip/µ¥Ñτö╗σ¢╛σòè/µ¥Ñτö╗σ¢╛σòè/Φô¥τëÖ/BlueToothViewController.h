//
//  BlueToothViewController.h
//  来画图啊
//
//  Created by ydcy-mini on 2017/4/21.
//  Copyright © 2017年 ydcy-mini. All rights reserved.
//

#import <UIKit/UIKit.h>

@class sb;
@interface BlueToothViewController : UIViewController

@property (nonatomic, strong) sb  *ssss;

@end
