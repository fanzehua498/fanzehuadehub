//
//  ViewController.m
//  来画图啊
//
//  Created by ydcy-mini on 2017/3/23.
//  Copyright © 2017年 ydcy-mini. All rights reserved.
//

#import "ViewController.h"
#import "LearnTableViewController.h"

#import <objc/runtime.h>

#import "ViewViewView.h"
#import "FZHAnimationLable.h"
#import "CoinView.h"
#import "FzhTextField.h"

#import "FZHLoveView.h"

#import "TwitterView.h"
#import "MNWheelView.h"
#import "FZHFunction.h"
#import "UIImage+FZHImage.h"

#import "FZHAlertView.h"
#import "FZHFunction.h"


@interface ViewController ()<UITextFieldDelegate>
{
    FZHLoveView *fzhview;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.


    //    FzhTextField *field = [[FzhTextField alloc] initWithFrame:CGRectMake(100,200, 200, 20)];
//    field.adjustsFontSizeToFitWidth = YES;
//    field.placeholder = @"placeholder";
//    field.userInteractionEnabled = YES;
//    field.borderStyle = UITextBorderStyleRoundedRect;
//    field.delegate = self;
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changesizeWithField:) name:UITextFieldTextDidChangeNotification object:field];

//    [field addObserver:self forKeyPath:@"text" options:NSKeyValueObservingOptionOld | NSKeyValueObservingOptionNew context:nil];
//    field addTarget:<#(nullable id)#> action:<#(nonnull SEL)#> forControlEvents:<#(UIControlEvents)#>
//    [self.view addSubview:field];

   // UIImage *image;
   // image imageWithRenderingMode:<#(UIImageRenderingMode)#>
   // CGContextRef ref = UIGraphicsGetCurrentContext();
   // CGRect rec = CGRectMake(0, 0, 10, 100);
   // CGContextAddRect(ref, rec);
    //CGContextSetStrokeColor(ref, 120);
    //CGContextSetRGBStrokeColor(ref, 80, 80, 80, 1);
    //CGContextStrokePath(ref);
//    CGRect rect = [UIScreen mainScreen].bounds;
//    ViewViewView *view =[[ViewViewView alloc] initWithFrame:rect];
//    view.backgroundColor = [UIColor grayColor];
//    [self.view addSubview:view];
//    [self labelAnimatioin];
//    [self conview];

    UIButton *button = [UIButton buttonWithType:UIButtonTypeContactAdd];
    [button addTarget:self action:@selector(jumpToLearn:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *it = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = it;
    self.view.backgroundColor = [UIColor whiteColor];

    UITextView *textViw = [[UITextView alloc] initWithFrame:CGRectMake(0, 80, 100, 40)];
    textViw.font = [UIFont systemFontOfSize:15];
    textViw.autocorrectionType =UITextAutocorrectionTypeNo;
    textViw.backgroundColor = [UIColor grayColor];
//    [self.view addSubview:textViw];

    FZHFunction *f = [[FZHFunction alloc] init];
//    int * a = 123456789;
    NSMutableArray *ar = [NSMutableArray arrayWithArray:@[@10,@9,@100,@8,@7,@0]];

    
//    int i = [f halfFunctionIntArr:@[@10,@20,@30,@40,@50,@60,@70,@80,@90]  number:1];
//    int i1 = [f halfFunctionIntArr:@[@10,@20,@30,@40,@50,@60,@70,@80,@90]  number:20];
//    int i2 = [f halfFunctionIntArr:@[@10,@20,@30,@40,@50,@60,@70,@80,@90]  number:30];
//    int i3 = [f halfFunctionIntArr:@[@10,@20,@30,@40,@50,@60,@70,@80,@90]  number:40];
//    int i4 = [f halfFunctionIntArr:@[@10,@20,@30,@40,@50,@60,@70,@80,@90]  number:50];
//    int i5 = [f halfFunctionIntArr:@[@10,@20,@30,@40,@50,@60,@70,@80,@90]  number:60];
//    int i6 = [f halfFunctionIntArr:@[@10,@20,@30,@40,@50,@60,@70,@80,@90]  number:70];
//    int i7 = [f halfFunctionIntArr:@[@10,@20,@30,@40,@50,@60,@70,@80,@90]  number:80];
//    int i8 = [f halfFunctionIntArr:@[@10,@20,@30,@40,@50,@60,@70,@80,@90]  number:90];
//    NSLog(@"i=====%d \n %d\n %d\n %d\n %d\n %d\n %d\n %d\n %d",i,i1,i2,i3,i4,i5,i6,i7,i8);

    TwitterView *v = [[TwitterView alloc] init];
    [v addLayerToLaunchView];
    [self.view addSubview:v];
    [UIView animateWithDuration:10 animations:^{
        // 这里先把View缩小
        v.frame = CGRectMake(0, 0, 50, 50);
        v.center = self.view.center;
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:10 animations:^{
            // 这里要把View放大
            v.frame = CGRectMake(0, 0, 5000, 5000);
            v.center = self.view.center;
            v.alpha = 0;
        } completion:^(BOOL finished) {
            [v removeFromSuperview];
        }];;
    }];


    NSString *market = [NSString stringWithFormat:@"¥%@",@"500"];
    NSMutableAttributedString *attributeMarket = [[NSMutableAttributedString alloc] initWithString:market];
    [attributeMarket setAttributes:@{NSStrikethroughStyleAttributeName: [NSNumber numberWithInteger:NSUnderlineStyleSingle]} range:NSMakeRange(0,market.length)];
    UILabel *marketLabel = [[UILabel alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
    marketLabel.attributedText = attributeMarket;
    [self.view addSubview:marketLabel];


//    [self testJDMianshi];
//
//    [self createRunTimeUI];

    [self drawLove];
}

- (void)testJDMianshi{
    int a[5] = {1, 2, 3, 4, 5};
    int *ptr = (int *)(&a + 1);
    NSLog(@"ssss");
    printf("mmmmmmm:%d, %d", *(a + 1), *(ptr + 1));
}

- (void)testYOUKUmianshi
{
    int a = -1, b = 4, k;
    printf("%d ",a);
    printf("%d ",a++);
    printf("%d ",a);
    k = (a++<=0) && (!(b--<=0));
    printf("%d%d%d\n", k, a, b);
}

- (void)jumpToLearn:(id)sender
{
    LearnTableViewController *learn = [[LearnTableViewController alloc] init];
    [self.navigationController pushViewController:learn animated:YES];
}

- (void)conview{

    CoinView *view = [[CoinView alloc] initWithFrame:self.view.frame];
    view.backgroundColor = [UIColor clearColor];

    [self.view addSubview:view];

}

- (void)labelAnimatioin
{
    FZHAnimationLable *label = [[FZHAnimationLable alloc] initWithFrame:CGRectMake(0, 250, 375, 60)];
    label.attributedString = [[NSAttributedString alloc] initWithString:@"你别是个智障吧，请问在刹那间卡上的杰克逊走 i 前往南昌，那时的健康咯 i 家去乌克兰籍大赛开幕了"];
//    label.text = @"你别是个智障吧，请问在刹那间卡上的杰克逊走 i 前往南昌，那时的健康咯 i 家去乌克兰籍大赛开幕了";
    label.repeatCount = 1;
    label.textColor = [UIColor grayColor];
    label.font = [UIFont systemFontOfSize:17];
    label.speed = FZHSpeedMid;

    [self.view addSubview:label];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)drawDraw
{
    UIBezierPath *path = [UIBezierPath bezierPath];
    NSArray *arr;
    [arr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {

    }];
}



- (void)changesizeWithField:(UITextField *)field
{
    CGFloat width = [field.text boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, 20) options:NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17]} context:nil].size.width;
    NSLog(@"%lf",width);
    if (width > field.bounds.size.width) {
        [field setNeedsDisplay];
    }
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{

    CGFloat width = [textField.text boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, 20) options:NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17]} context:nil].size.width;
    NSLog(@"%lf %@",width,textField.text);
    NSLog(@"%@",string);

    if (width > textField.bounds.size.width) {

        return NO;
    }
    return YES;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField
{

}
-(void)textFieldDidEndEditing:(UITextField *)textField 
{
//    CGFloat width = [textField.text boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, 20) options:NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17]} context:nil].size.width;
//    NSLog(@"%lf",width);
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
//    NSLog(@"%@ call %@",NSStringFromSelector(_cmd),NSStringFromSelector(@selector(touchesBegan:withEvent:)));
    UIButton *button = objc_getAssociatedObject(self.view, @"button");
    NSLog(@"%@",button.currentTitle);
    NSInteger i = arc4random()%100;
    [button setTitle:[NSString stringWithFormat:@"butt%ld",i] forState:UIControlStateNormal];

}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context
{

        NSLog(@"%@",change);

}

- (void)createRunTimeUI
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(100, 300, 100, 30);
    [button setTitle:@"button" forState:UIControlStateNormal];
    [self.view addSubview:button];
    objc_setAssociatedObject(self.view, @"button", button, OBJC_ASSOCIATION_ASSIGN);

}

/**
 *  CGContextRef context = UIGraphicsGetCurrentCont ext(); 设置上下文
 *   CGContextMoveToPoint 开始画线
    CGContextAddLineToPoint 画直线
    CGContextAddEllipseInRec t 画一椭圆
 */


- (void)drawLove
{
//    for (float y = 1.5; y > -1.5; y -= 0.08) {
//        for (float x = -1.5; x < 1.5; x += 0.04) {
//            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(x, y, 1, 1)];
//            [self.view addSubview:label];
//            if (x*x + pow(5.0 * y /4.0 - sqrt(fabs(x)), 2) - 1 <= 0.0) {
//
//                label.text = @"*";
//            }else{
////                UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(x, y, 10, 10)];
////                [self.view addSubview:label];
//                label.text = @".";
//            }
//        }
//    }




    for (float y = 153; y > 100; y -= 2) {
        for (float x = 100; x < 153; x += 2) {
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(x, y, 2, 2)];
//            [self.view addSubview:label];
//            label.backgroundColor = [UIColor redColor];

            float a = x*x + y *y -20*20;
//            NSLog(@"%f",a*a*a - x*x*y*y*y);
            char ch = a*a*a - x*x*y*y*y <= 0 ? 'f':' ';
            putchar(a*a*a - x*x*y*y*y <= 0 ? 'f':' ');
//            label.text = [NSString stringWithUTF8String:&ch];
        }
        putchar('\n');
    }

    fzhview = [[FZHLoveView alloc] initWithFrame:CGRectMake(0, 60, 200, 300)];
    fzhview.rate = 1;
    fzhview.lineWidth = 1;
    fzhview.strokeColor = [UIColor blueColor];
    fzhview.fillColor = [UIColor redColor];
    fzhview.backgroundColor = [UIColor clearColor];
    [self.view addSubview:fzhview];
    [self loadSlider];

    FZHAlertView *alview = [[FZHAlertView alloc] init];
    alview.frame = CGRectMake(300, 300, 100, 30);
    alview.begin(@"begin");
    [self.view addSubview:alview];
}
- (void)loadSlider
{
    UISlider *valueSlider = [[UISlider alloc]initWithFrame:CGRectMake((self.view.frame.size.width-300)/2, self.view.frame.size.height-150, 300, 50)];
    valueSlider.minimumValue = 0.0;
    valueSlider.maximumValue = 1.0;
    valueSlider.value = 0.5;
    [valueSlider addTarget:self action:@selector(valueChangedAction:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:valueSlider];
}

- (void)valueChangedAction:(UISlider*)slider
{
    fzhview.rate = slider.value;
}
@end
