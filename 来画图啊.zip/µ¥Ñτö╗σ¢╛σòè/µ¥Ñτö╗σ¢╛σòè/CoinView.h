//
//  CoinView.h
//  来画图啊
//
//  Created by ydcy-mini on 2017/4/5.
//  Copyright © 2017年 ydcy-mini. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kCoinCountNumber 300 //金币总数
@interface CoinView : UIView

@end
