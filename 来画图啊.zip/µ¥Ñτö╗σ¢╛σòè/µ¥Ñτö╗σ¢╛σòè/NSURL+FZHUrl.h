//
//  NSURL+FZHUrl.h
//  来画图啊
//
//  Created by ydcy-mini on 2017/5/25.
//  Copyright © 2017年 ydcy-mini. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSURL (FZHUrl)
+ (instancetype)fzhURlWithString:(NSString *)urls;
@property (nonatomic, strong) NSString  *test;
@end
