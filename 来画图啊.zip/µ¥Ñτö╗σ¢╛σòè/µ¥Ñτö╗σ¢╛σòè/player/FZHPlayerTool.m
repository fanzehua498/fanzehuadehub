//
//  FZHPlayerTool.m
//  来画图啊
//
//  Created by ydcy-mini on 2017/5/5.
//  Copyright © 2017年 ydcy-mini. All rights reserved.
//

#import "FZHPlayerTool.h"
#import <AVFoundation/AVFoundation.h>
@implementation FZHPlayerTool

-(instancetype)init
{
    self = [super init];
    if (!self) {

    }
    return self;
}

- (void)getSession
{
    AVCaptureSession *session = [[AVCaptureSession alloc] init];
}
@end
